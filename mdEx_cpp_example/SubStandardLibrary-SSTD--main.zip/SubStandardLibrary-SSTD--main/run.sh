make && ./exe
