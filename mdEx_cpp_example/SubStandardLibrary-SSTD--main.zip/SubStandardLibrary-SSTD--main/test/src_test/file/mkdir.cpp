#include <sstd/sstd.hpp>
#include "../../gtest_parallel/test_main.hpp"

//-----------------------------------------------------------------------------------------------------------------------------------------------

/*
void TEST_mkdir(){
    printf("■ mkdir\n\n");
    sstd::mkdir("./test_mkdir/abc/def"); // enable to make multilayer directory by one step.
    sstd::mkdir(std::string("./test_mkdir/abc/def")); // enable to make multilayer directory by one step.
}
*/

//-----------------------------------------------------------------------------------------------------------------------------------------------

EXECUTE_TESTS();
