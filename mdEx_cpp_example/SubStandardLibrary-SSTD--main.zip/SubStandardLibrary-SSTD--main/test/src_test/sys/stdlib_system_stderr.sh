#!/bin/bash
echo 'hello-stderr' >&2
exit 255
