#include <sstd/sstd.hpp>
#include "../../gtest_parallel/test_main.hpp"

//-----------------------------------------------------------------------------------------------------------------------------------------------

/*
TEST(signal, case_xx){
    printf("■ generate signal\n");
    double freq2generate = 3; // Hz
    double freq2sample = 10;  // Hz
    uint len=10;              // 10 Hz 10 sample = 1 sec
    std::vector<double> sin_wave = sstd::sinWave(freq2generate, freq2sample, len);
    std::vector<double> cos_wave = sstd::cosWave(freq2generate, freq2sample, len);
}
*/

//-----------------------------------------------------------------------------------------------------------------------------------------------

EXECUTE_TESTS();
