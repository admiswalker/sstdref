﻿#include <sstd/sstd.hpp>
#include "../../gtest_parallel/test_main.hpp"

/*
TEST(typeDef, case_xx){
    printf("■ typeDef\n");
    uchar   uc =  1; printf("uchar:  %u\n",     uc);
    uint    ui =  2; printf("uint:   %u\n",     ui);
    uint8   u8 =  8; printf("uint8:  %u\n",     u8);
    uint16 u16 = 16; printf("uint16: %u\n",    u16);
    uint32 u32 = 32; printf("uint32: %u\n",    u32);
    uint64 u64 = 64; printf("uint64: %lu\n\n", u64);
}
*/

EXECUTE_TESTS();

