#pragma once

#include "../../container/matrixContainer_colMajor/mat_c.hpp"

/*
namespace sstd{
}
//*/

