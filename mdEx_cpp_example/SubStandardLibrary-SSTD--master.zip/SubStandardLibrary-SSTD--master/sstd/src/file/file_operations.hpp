#pragma once

#include <stddef.h>
#include "../typeDef.h"

namespace sstd{
    bool file_size(size_t& ret_size, const char* path);
}
