#pragma once
#include "../definitions/typeDef.h"

namespace sstd{
    int32 getpid();
}


